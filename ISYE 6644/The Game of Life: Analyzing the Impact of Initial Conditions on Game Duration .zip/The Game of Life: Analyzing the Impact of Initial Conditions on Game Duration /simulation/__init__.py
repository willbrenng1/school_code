from .gol_functions import (
    generate_rand_matrix,
    get_neighbors,
    next_gen,
    matrix_data_collection,
    run_game,
    sample_runs,
    final_run,
)
